/*
 * rosserial_ids.h
 *
 *  Created on: Aug 5, 2011
 *      Author: astambler
 */

#ifndef ROSSERIAL_IDS_H_
#define ROSSERIAL_IDS_H_

#define TOPIC_NEGOTIATION   0
#define TOPIC_PUBLISHERS    0
#define TOPIC_SUBSCRIBERS   1
#define TOPIC_SERVICES      2

#endif /* ROSSERIAL_IDS_H_ */
